Tecnologias usadas
Node.js (v18+ recomendado)
Next.js 14+
React 18
TailwindCSS 3+
shadcn/ui (componentes estilizados)
TypeScript


Rodar o servidor
Após instalar tudo, execute:
npm run dev


Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process

