"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

// ===============================
//      TIPOS
// ===============================
type Comment = {
  authorName: string;
  authorPhoto: string;
  text: string;
  timestamp: number; // para calcular "3 min atrás"
};

type Post = {
  id: number;
  authorName: string;
  authorPhoto: string;
  content: string;
  image: string | null;
  likes: number;
  comments: Comment[];
};

// ===============================
//  Função para formatar o tempo
// ===============================
function timeAgo(timestamp: number) {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);

  if (seconds < 5) return "Agora mesmo";
  if (seconds < 60) return `${seconds} seg atrás`;

  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} min atrás`;

  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h atrás`;

  const days = Math.floor(hours / 24);
  return `${days} dias atrás`;
}

// ===============================
//      COMPONENTE PRINCIPAL
// ===============================
export default function HomePage() {
  const [posts, setPosts] = useState<Post[]>([
    {
      id: 1,
      authorName: "João Silva",
      authorPhoto: "https://i.pravatar.cc/150?img=1",
      content: "Primeiro dia de aula! 😄📚",
      image: "https://picsum.photos/500/300?random=1",
      likes: 4,
      comments: [],
    },
    {
      id: 2,
      authorName: "Profª Ana Souza",
      authorPhoto: "https://i.pravatar.cc/150?img=5",
      content: "Curiosidade sobre tecnologia e IA! 🤖",
      image: "https://picsum.photos/500/300?random=2",
      likes: 10,
      comments: [],
    },
  ]);

  const [newPost, setNewPost] = useState("");
  const [editPost, setEditPost] = useState<Post | null>(null);
  const [commentText, setCommentText] = useState<Record<number, string>>({});

  // ===============================
  //  NOVO POST
  // ===============================
  function handleCreatePost() {
    if (!newPost.trim()) return;

    const newPostObj: Post = {
      id: Date.now(),
      authorName: "Você",
      authorPhoto: "https://i.pravatar.cc/150?img=12",
      content: newPost,
      image: null,
      likes: 0,
      comments: [],
    };

    setPosts([newPostObj, ...posts]);
    setNewPost("");
  }

  // ===============================
  //  LIKE
  // ===============================
  function handleLike(id: number) {
    setPosts(
      posts.map((p) => (p.id === id ? { ...p, likes: p.likes + 1 } : p))
    );
  }

  // ===============================
  //  COMENTAR
  // ===============================
  function handleAddComment(id: number) {
    const text = commentText[id]?.trim();
    if (!text) return;

    const newComment: Comment = {
      authorName: "Você",
      authorPhoto: "https://i.pravatar.cc/150?img=12",
      text,
      timestamp: Date.now(),
    };

    setPosts(
      posts.map((p) =>
        p.id === id ? { ...p, comments: [...p.comments, newComment] } : p
      )
    );

    setCommentText({ ...commentText, [id]: "" });
  }

  // ===============================
  //  EDITAR
  // ===============================
  function handleEditPost() {
    if (!editPost) return;
    setPosts(posts.map((p) => (p.id === editPost.id ? editPost : p)));
    setEditPost(null);
  }

  // ===============================
  //      RENDER
  // ===============================
  return (
    <div className="min-h-screen p-6 bg-gray-100">
      {/* HEADER */}
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-blue-700">LeoLinks</h1>
        <Button>Meu Perfil</Button>
      </header>

      {/* CRIAR POST */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <Textarea
            placeholder="Compartilhe algo com a UniAsselvi..."
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
          />
          <Button className="w-full mt-4" onClick={handleCreatePost}>
            Postar
          </Button>
        </CardContent>
      </Card>

      {/* FEED */}
      <div className="space-y-6">
        {posts.map((post) => (
          <Card key={post.id}>
            <CardHeader className="flex flex-row items-center gap-3">
              <Avatar>
                <AvatarImage src={post.authorPhoto} />
                <AvatarFallback>{post.authorName[0]}</AvatarFallback>
              </Avatar>

              <div>
                <p className="font-semibold">{post.authorName}</p>

                {/* botão profil */}
                <button className="text-blue-600 underline text-sm cursor-pointer">
                  Ver Perfil
                </button>
              </div>
            </CardHeader>

            <CardContent>
              <p className="mb-3">{post.content}</p>

              {post.image && (
                <img
                  src={post.image}
                  className="rounded-xl mb-3"
                  alt="post"
                />
              )}

              {/* Ações */}
              <div className="flex gap-3 mt-4 mb-3">
                <Button onClick={() => handleLike(post.id)}>
                  👍 Like ({post.likes})
                </Button>

                <Button
                  variant="secondary"
                  onClick={() => {
                    const element = document.getElementById(`comment-${post.id}`);
                    element?.scrollIntoView({ behavior: "smooth" });
                  }}
                >
                  💬 Comentar
                </Button>

                <Button variant="outline" onClick={() => setEditPost(post)}>
                  ✏️ Editar
                </Button>
              </div>

              {/* COMENTÁRIOS */}
              <div id={`comment-${post.id}`}>
                <Textarea
                  placeholder="Escreva um comentário..."
                  value={commentText[post.id] || ""}
                  onChange={(e) =>
                    setCommentText({
                      ...commentText,
                      [post.id]: e.target.value,
                    })
                  }
                />

                <Button
                  className="mt-2"
                  onClick={() => handleAddComment(post.id)}
                >
                  Enviar Comentário
                </Button>

                <div className="mt-4 space-y-3">
                  {post.comments.map((c, index) => (
                    <div
                      key={index}
                      className="flex items-start gap-3 bg-gray-200 p-3 rounded-lg"
                    >
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={c.authorPhoto} />
                        <AvatarFallback>{c.authorName[0]}</AvatarFallback>
                      </Avatar>

                      <div>
                        <p className="font-semibold text-sm text-gray-800">
                          {c.authorName} ·{" "}
                          <span className="text-gray-500">
                            {timeAgo(c.timestamp)}
                          </span>
                        </p>
                        <p className="text-gray-900">{c.text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* EDITAR POST */}
      <Dialog open={!!editPost} onOpenChange={() => setEditPost(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Post</DialogTitle>
          </DialogHeader>

          <Textarea
            value={editPost?.content}
            onChange={(e) =>
              setEditPost({ ...editPost!, content: e.target.value })
            }
          />

          <Button className="w-full mt-4" onClick={handleEditPost}>
            Salvar
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
